//============================================================
// Include Libraries
//============================================================
#include <Arduino.h>
#include "Freenove_WS2812_Lib_for_ESP32.h"
#include <Wire.h>
#include "MLX90641_API.h"
#include "MLX90640_API.h"
#include "MLX9064X_I2C_Driver.h"
#include <time.h>
#include <string>
#include <stdio.h>
#include <stdlib.h>

//============================================================
// Configurations (can be modifiled)
//============================================================

// Variables to hold data from custom textboxes
// -------------------------------------------------
// configuration for MLX sensor
int MLX_type = 0;                  // 0: MLX90640; 1: MLX90641
int refreshrate = 8;              // valid values: 0(0.5 Hz),1,2,4,8,16,32,64
int reading_type = 1;              // 1: one frame contain one subpage. 2: one frame contains two subpages;
float emissivity = 1.0;            // the emissivity setting of sensor
int ambient_temperature_shift = 8; // 5:mlx90641; 8:mlx90640

//============================================================
// Settings (can not be modifield)
//============================================================

// for onboard RGB LED // --------------------------
#define LEDS_COUNT 1
#define LEDS_PIN 48
#define CHANNEL 0
Freenove_ESP32_WS2812 strip = Freenove_ESP32_WS2812(LEDS_COUNT, LEDS_PIN, CHANNEL, TYPE_GRB);
u8 m_color[11][3] = {{0, 0, 0}, {160, 32, 240}, {238, 197, 145}, {139, 0, 139}, {255, 255, 255}, {255, 255, 0}, {255, 0, 255}, {0, 255, 255}, {0, 0, 255}, {0, 255, 0}, {255, 0, 0}};

// For configuration storage in Flash// --------------------------
#define ESP_DRD_USE_SPIFFS true
// JSON configuration file
#define JSON_CONFIG_FILE "/config.json"
// Flag for saving data
bool shouldSaveConfig = false;

// for MLX sensor // --------------------------
// uint8_t REFRESH_0_5_HZ = 0b000; // 0.5Hz
// uint8_t REFRESH_1_HZ = 0b001;   // 1Hz
// uint8_t REFRESH_2_HZ = 0b010;   // 2Hz
// uint8_t REFRESH_4_HZ = 0b011;   // 4Hz
// uint8_t REFRESH_8_HZ = 0b100;   // 8Hz
// uint8_t REFRESH_16_HZ = 0b101;  // 16Hz
// uint8_t REFRESH_32_HZ = 0b110;  // 32Hz
// uint8_t REFRESH_64_HZ = 0b111;  // 64Hz
// default refreshrate
uint8_t refreshrate_u8 = 0b101;  // 16Hz; // default refreshrate
// Common variables
const byte MLX9064x_address = 0x33;        // Default 7-bit unshifted address of the MLX9064x // the default I2C address of the sensor
#define TA_SHIFT ambient_temperature_shift // Default shift for MLX9064x in open air
// for mlx90640:
static float mlx90640To[768];
static float tr; // Reflected temperature based on the sensor ambient temperature
paramsMLX90640 mlx90640;

std::string float_array_to_string(float int_array[], int size_of_array)
{
  std::string returnstring = "[";
  for (int temp = 0; temp < size_of_array; temp++)
  {
    returnstring += std::to_string(int_array[temp]);
    returnstring += ",";
  }
  returnstring += "]";
  return returnstring;
}

boolean isConnected()
{
  Wire.beginTransmission((uint8_t)MLX9064x_address);
  if (Wire.endTransmission() != 0)
  {
    return (false); // Sensor did not ACK
  }
  return (true); // Returns true if the MLX9064x is detected on the I2C bus
}


void setup()
{
  // Setup Serial monitor  ----------------------------------------------------
  // 921600
  Serial.begin(921600);
  // Setup the RGB LED // As a sign of different program phase  ----------------------------------------------------
  strip.begin();
  strip.setBrightness(10);

  strip.setLedColorData(0, m_color[0][0], m_color[0][1], m_color[0][2]);
  strip.show();
  delay(500);

  // Setup MLX sensor ----------------------------------------------------
  Wire.begin(17, 18, 1000000); // (SDA_pin,SCL_pin, Baudrate)// i2c setting
  switch (refreshrate)
  {
  case 0:
    refreshrate_u8 = 0b000;
    break;
  case 1:
    refreshrate_u8 = 0b001;
    break;
  case 2:
    refreshrate_u8 = 0b010;
    break;
  case 4:
    refreshrate_u8 = 0b011;
    break;
  case 8:
    refreshrate_u8 = 0b100;
    break;
  case 16:
    refreshrate_u8 = 0b101;
    break;
  case 32:
    refreshrate_u8 = 0b110;
    break;
  case 64:
    refreshrate_u8 = 0b111;
    break;
  default:
    refreshrate_u8 = 0b101;
  }
  // setting the refreshrate

  MLX90640_SetRefreshRate((uint8_t)MLX9064x_address, refreshrate_u8);

  // setting i2c
  Serial.println("Set I2C");
  if (isConnected() == false)
  {
    Serial.println("MLX9064x not detected at default I2C address. Please check wiring. Freezing.");
    ESP.restart();
  }
  Serial.println("MLX9064x online!");

  strip.setLedColorData(0, m_color[6][0], m_color[6][1], m_color[6][2]);
  strip.show();
  delay(500);
  // Get device parameters - We only have to do this once
  int status;
  uint16_t eeMLX9064x[832];

  status = MLX90640_DumpEE(MLX9064x_address, eeMLX9064x);

  if (status != 0)
  {
    Serial.println("Failed to load system parameters");
  }

  status = MLX90640_ExtractParameters(eeMLX9064x, &mlx90640);

  if (status != 0)
  {
    Serial.println("Parameter extraction failed");
  }

  // Once params are extracted, we can release eeMLX9064x array
  strip.setLedColorData(0, m_color[7][0], m_color[7][1], m_color[7][2]);
  strip.show();
  delay(500);

  Serial.println("Finish Setting");
  
}

int return_file_size_count = 0;

void loop()
{
  strip.setLedColorData(0, m_color[6][0], m_color[6][1], m_color[6][2]);
  strip.show();
  // Read Sensor data from MLX sensor to EXP32

  for (int pixelNumber = 0; pixelNumber < 768; pixelNumber++)
  {
    mlx90640To[pixelNumber] = 0.0;
  }

  for (int x = 0; x < reading_type; x++)
  { // Read both subpages or single subpage
    uint16_t mlx90640Frame[834];
    int status = MLX90640_GetFrameData(MLX9064x_address, mlx90640Frame);
    if (status < 0)
    {
      Serial.print("GetFrame Error: ");
      Serial.println(status);
      x--;
      continue;
    }
    float Ta = MLX90640_GetTa(mlx90640Frame, &mlx90640);
    tr = Ta - ambient_temperature_shift; // Reflected temperature based on the sensor ambient temperature
    MLX90640_CalculateTo(mlx90640Frame, &mlx90640, emissivity, tr, mlx90640To);
  }

  std::string message = "{"; // the message to be sent
  message += "\"loc_ts\":";
  message += std::to_string(millis());
  message += ", \"at\":";
  message += std::to_string(tr);
  message += ", \"temperature\":";
  std::string data = float_array_to_string(mlx90640To, 768);
  message += data;
  message += "}";
  strip.setLedColorData(0, m_color[7][0], m_color[7][1], m_color[7][2]);
  strip.show();

  Serial.println(message.c_str());
}
